import { Link } from "react-router-dom";
import darkLogoImg from "../../assets/logo/transparent-logo.png";


const DarkLogo = () => {
  return (
    <Link to="/" aria-label="ALFA Appliances home" className="shrink-0">
      <img
        src={darkLogoImg}
        alt="ALFA Appliances"
        width={143}
        height={66}
        className="h-[66px] w-[143px] object-contain"
      />
    </Link>
  );
};

export default DarkLogo;